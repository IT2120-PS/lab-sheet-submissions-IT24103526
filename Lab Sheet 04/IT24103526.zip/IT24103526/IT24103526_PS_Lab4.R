setwd("C:\\Users\\HP\\Desktop\\IT24103526")
getwd()

branch_data <- read.table("Exercise.txt", header = TRUE, sep=",")
fix(branch_data)


head(branch_data)
colnames(branch_data)
str(branch_data)

boxplot(branch_data$Sales_X1, main = "Boxplot of Sales (X1)", ylab = "Sales", col = "lightblue", outline = TRUE)


summary(branch_data$Advertising_X2)  # This gives min, Q1, median, mean, Q3, max
IQR(branch_data$Advertising_X2)      # Interquartile range



find_outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3 - q1
  lower_bound <- q1 - 1.5 * iqr
  upper_bound <- q3 + 1.5 * iqr
  
  outliers <- x[x < lower_bound | x > upper_bound]
  
  cat("Lower Bound:", lower_bound, "\n")
  cat("Upper Bound:", upper_bound, "\n")
  if (length(outliers) > 0) {
    cat("Outliers:", paste(sort(outliers), collapse = " "), "\n")
  } else {
    cat("No outliers found.\n")
  }
}
find_outliers(branch_data$Years_X3)



























